# AI Security Readiness Assessment

A combined vulnerability impact calculator + security posture quiz, built as a standalone page for your Hugo site on Netlify.

## Quick Deploy (Hugo + Netlify)

### Option A: Standalone page (simplest)

Drop the HTML file into your Hugo project's `static/` folder:

```
your-hugo-site/
├── static/
│   └── ai-security-readiness/
│       └── index.html        ← just this file
```

After deploying, the tool will be live at:
```
https://yourdomain.com/ai-security-readiness/
```

That's it. No build step, no npm, no dependencies.

### Option B: As a Hugo content page (inherits your site layout)

If you want it to sit inside your Hugo layout with your site's nav/footer:

1. Create a new content file:

```
your-hugo-site/
├── content/
│   └── projects/
│       └── ai-security-readiness.md
```

2. Add this frontmatter to `ai-security-readiness.md`:

```yaml
---
title: "AI Security Readiness Assessment"
description: "Assess your organization's vulnerability exposure and readiness for the AI security era."
date: 2026-04-11
layout: "ai-security-readiness"
---
```

3. Create a matching layout at `layouts/_default/ai-security-readiness.html` (or under your theme's layouts) and paste the full HTML content from `index.html` there, wrapping it inside your base template.

Option A is recommended — it's self-contained and won't conflict with your theme.

## Linking from your LinkedIn Post

Add this line near the end of your article, before the closing CTA:

> "I built a quick tool to help you assess where you stand — try it here: [yourdomain.com/ai-security-readiness](https://yourdomain.com/ai-security-readiness/)"

## What's Inside

- **Vulnerability Impact Calculator**: Users input their stack type, languages, and dependency count. The tool estimates undiscovered vulnerabilities and compares exposure windows with vs. without AI-assisted scanning.

- **Security Posture Quiz**: 6 questions across 3 categories (Secure Design, AI Integration, Internal Readiness). Produces a letter grade (A-D) with category breakdowns and tailored action items.

- **Combined Results**: Unified report merging both assessments with personalized recommendations based on score tier.

## Customization

Everything is in a single HTML file. To customize:

- **Colors**: Edit the CSS variables in the `:root` block at the top of `<style>`
- **Questions**: Edit the `QUIZ` array in the `<script>` block
- **Stack options**: Edit the `STACKS` and `LANGUAGES` arrays
- **Recommendations**: Edit the action items in the `renderResults()` function
- **Fonts**: The tool loads JetBrains Mono and Outfit from Google Fonts

## Tech Details

- Zero dependencies — pure HTML/CSS/JS
- No build step required
- Mobile responsive
- ~18KB total (before gzip)
- Loads 2 Google Fonts via CDN
- No cookies, no tracking, no external API calls
- All computation happens client-side
